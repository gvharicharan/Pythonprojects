Python 3.8.5 (tags/v3.8.5:580fbb0, Jul 20 2020, 15:43:08) [MSC v.1926 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> word="supercalifragilisticexpialidocious"
>>> word[0]
's'
>>> word
'supercalifragilisticexpialidocious'
>>> word[2]
'p'
>>> word[0:5:1]
'super'
>>> word[5:9]
'cali'
>>> word[5:]
'califragilisticexpialidocious'
>>> word[5::2]
'clfaiitcxildcos'
>>> word[:7]
'superca'
>>> word[:8]
'supercal'
>>> word[-2]
'u'
>>> word.index("cali")
5
>>> word.index("fragi")
9
>>> word[word.index("cali"):word.index("fragi")]
'cali'
>>> word[word.index("docious")]
'd'
>>> word[word.index("fragilistic"):word.index("exp")]
'fragilistic'
>>> word[word.index("fragilistic"):word.index("exp")]
'fragilistic'
>>> 
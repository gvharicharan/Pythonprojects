vowels=0
consonants=0

for letter in "Charan":
    if letter.lower() in "aeiou":
        vowels=vowels+1

    elif letter=="":
        pass
    else:
        consonants=consonants+1

print("There are {} vowels".format(vowels))
print("There are {} consonants".format(consonants))


students={
    "male":["Akhil","Avinash","Sivareddy","David","Varma"],
    "female":["Ariyana","Geetha","Sowmya","Madhumati","Shalini"]
    }
for key in students.keys():
    for name in students[key]:
        if "a" in name:
            print(name)
